TO RUN EACH OF THESE PROGRAMS: python3 <filename>

For program A:

Takes in a key value as an input
The message is hard coded in the python file: 'This class is not hard at all.'
This is because it was time consuming to enter this message after every run while debugging.
The output is concatenated decimal values for each of the encrypted characters.

For program B:

Takes in a 8-length str to encrypt and then decrypt
The output of the messages are from each round of encrypting and decrypting in the form of byte arrays.